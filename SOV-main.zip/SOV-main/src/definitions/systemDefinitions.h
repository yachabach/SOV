// Combination of all definition files
#pragma once

#include "constants.h"
#include "types.h"