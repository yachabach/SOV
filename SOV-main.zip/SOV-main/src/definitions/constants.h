#pragma once

// #include "./Motor/constants.h"
// #include "./UserInterruptModule/constants.h"

// System constants
const unsigned long SEEK_HOME_LIMIT = 5000; // ms
const byte CRUISE_SPEED = 100;              //% power
const byte FULL_SPEED = 100;
