#include "./InterruptTimerModule/interrupt-timer.h"

float timeDiff(unsigned long, unsigned long);
